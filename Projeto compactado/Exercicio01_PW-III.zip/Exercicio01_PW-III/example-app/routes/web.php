<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    return view('home');
});

Route::get('/adm', function () {
    return view('adm');
});

Route::get('/rh', function () {
    return view('rh');
});

Route::get('/log', function () {
    return view('log');
});

Route::get('/ds', function () {
    return view('ds');
});

Route::get('/jur', function () {
    return view('jur');
});

Route::get('/ds_ams', function () {
    return view('ds-ams');
});

Route::get('/cont', function () {
    return view('cont');
});
